#include <stdio.h>

int main() {
    printf("Hello, SACM!");
    return 0;
}